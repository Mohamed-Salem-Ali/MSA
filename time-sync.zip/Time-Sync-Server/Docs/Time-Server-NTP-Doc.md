# NTP Server to Sync Devices in a Network

You can sync the time on your PCs using the Network Time Protocol (NTP).

## Run the `Time-Server/time-server` binary program to set your Server time to the time that comes from the high level

**NOTE: RUN THIS PROGRAM ON THE SERVER THAT RUNS LINK776**

```bash
cd Time-Server
sudo ./time-server
```

## Setup an NTP Server

Choose a CentOS machine to hold your NTP server:

### Option 1 - Use ntp-configure.sh script

```bash
chmod +x ntp-configure.sh
sudo ./ntp-configure.sh
```
Confirm the ntp server is installed and running using the following command, it should output active

```bash
sudo service ntp status 
```
OR 
```bash
sudo systemctl status ntp
```

### Option 2 - Manually

1. Open a terminal window.

2. Install the NTP client using the following command:

   ```bash
   sudo yum install ntp
   ```
   OR to install it locally on CentOS
   ```bash
   cd Packages/centos
   rpm -i autogen-libopts-5.18-5.el7.x86_64.rpm 
   rpm -i libedit-3.0-12.20121213cvs.el7.x86_64.rpm 
   rpm -i ntpdate-4.2.6p5-29.el7.centos.2.x86_64.rpm 
   rpm -i ntp-4.2.6p5-29.el7.centos.2.x86_64.rpm
   ```
3. Enable and Start the NTP service using the following command:

   ```bash
   sudo service ntp enable 
   # OR
   sudo systemctl enable ntp
   
   ```
   ```bash
   sudo service ntp start 
   # OR
   sudo systemctl start ntp
   ```
4. Edit the NTP configuration file using the following command:

   ```bash
   sudo nano /etc/ntp.conf
   ```

5. Add the following lines to the bottom of the file:

   ```bash
   server 127.127.1.0
   fudge 127.127.1.0 stratum 10
   restrict default kod nomodify notrap nopeer noquery
   restrict 127.0.0.1
   restrict ::1
   ```

6. Save the file and exit the editor.

7. Restart the NTP service using the following command:

   ```bash
   sudo service ntp restart 
   # OR
   sudo systemctl restart ntp
   ```

## Connect Windows Machines to the NTP Server

1. Open the Control Panel and select the "Date and Time" option.
2. Select the "Internet Time" tab.
3. Click on "Change Settings".
4. Check the box "Synchronize with an Internet time server".
5. In the "Server" field, enter the IP address of the Ubuntu machine.
6. Click on "Update Now" to synchronize the time.

Once you have set up NTP on all your PCs, they should automatically synchronize their time with each other. If you want to set a specific time zone like GMT+2, you can do so in the Date and Time settings on each PC.

## Connect Linux Machines to the NTP Server

1. Open a terminal window on the Linux machine.

2. Install the NTP client using the following command:

   ```bash
   sudo apt-get install ntp
   ```

3. Edit the NTP configuration file using the following command:

   ```bash
   sudo nano /etc/ntp.conf
   ```

4. Find the line that starts with "server" and add the IP address of the Ubuntu machine that you've set up as an NTP server. For example, if the IP address of the Ubuntu machine is 192.168.1.10, the line should look like this:

   ```bash
   server 192.168.1.10
   ```

5. Save the file and exit the editor.

6. Restart the NTP service using the following command:

   ```bash
   sudo service ntp restart
   ```

The Linux machine should now synchronize its time with the NTP server that you've set up. You can check if the synchronization is working by running the `ntpstat` command in the terminal. If the output shows that the machine is synchronized, then the time should be accurate.