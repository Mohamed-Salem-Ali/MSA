#!/bin/bash

cd Packages/centos/

rpm -i autogen-libopts-5.18-5.el7.x86_64.rpm 
rpm -i libedit-3.0-12.20121213cvs.el7.x86_64.rpm 
rpm -i ntpdate-4.2.6p5-29.el7.centos.2.x86_64.rpm 
rpm -i ntp-4.2.6p5-29.el7.centos.2.x86_64.rpm

service ntp enable 

service ntp start 

echo "server 127.127.1.0
fudge 127.127.1.0 stratum 10
restrict default kod nomodify notrap nopeer noquery
restrict 127.0.0.1
restrict ::1" > /etc/ntp.conf

service ntp restart 